Corey Kirschbaum
Zishu Wu

Part5:
Add feature of changing object symbols when an object hits a wall (boundry of screen). The object symbols rotate from using 'A' to 'G'.
