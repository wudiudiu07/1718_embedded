Corey Kirschbaum
Zishu Wu

All parts have their own folders. To execute code, run the ./run.sh script in the folder. 
You will have to modify the keyboard or arguments in the script when calling the ./part# executable.

Part1:
Run the ./run.sh script in the part1 folder.

Part2:
Run the ./run.sh script in the part2 folder.
./part2 argument gets passed in a 13-character string representing binary for the 13 tones: C(261.626) -> C(523.251).

Part3-6:
Run the ./run.sh script in the part3 folder.
The argument to this is the keyboard driver file path.
