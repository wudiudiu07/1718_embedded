#!/bin/sh
make clean
make
./part1