The file part3 is a sample solution for Part 3, and video.ko is a sample solution for the driver.
