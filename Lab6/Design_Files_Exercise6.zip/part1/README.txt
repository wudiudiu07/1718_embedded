The file part1 is a sample solution for Part 1, and video.ko is a sample solution for the driver.
