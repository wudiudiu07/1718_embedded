Part4 is an executable file and example solution to Part IV. It requires the driver
/dev/IntelFPGAUP/video, which can be found in /home/root/Linux_Libraries/drivers. This driver
implements the same functionality as the one that you are supposed to write as part of the 
solution to Part 4. 

The code creates an animation of moving boxes and lines on the VGA screen.

The program automatically exits after 12 seconds.
