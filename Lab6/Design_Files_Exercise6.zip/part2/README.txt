The file part2 is a sample solution for Part 2, and video.ko is a sample solution for the driver.
