part1 - part4 are executable code for sample solutions. Each program exits after 12 seconds.

wrappers* - examples of wrapper functions for the accel character device driver

accel*.ko are the character device drivers for Parts III and IV for the accelerometer.  
   To obtain usage, after inserting into the Linux kernel,  type echo -- > /dev/accel
